package com.example.animation_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
