package com.example.flutter_auth_animation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
