#include <iostream>
#include <cmath>
#include <iomanip>
#include <vector>
#include <string>

using namespace std;

//1 
int minNumber(int a, int b) {
    return (a < b) ? a : b;
}
//2
int gcd(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

int lcm(int a, int b) {
    int gcdValue = gcd(a, b);
    return (a * b) / gcdValue;
}
//3
int factorial(int n) {
    if (n <= 1) {
        return 1;
    } else {
        int result = 1;
        for (int i = 2; i <= n; ++i) {
            result *= i;
        }
        return result;
    }
}
//4 
double power(double X, int m) {
    double result = 1;
    for (int i = 0; i < m; ++i) {
        result *= X;
    }
    return result;
}
//5
int binomialCoefficient(int n, int k) {
    if (k < 0 || k > n) {
        return 0;
    } else {
        int numerator = factorial(n);
        int denominator = factorial(k) * factorial(n - k);
        return numerator / denominator;
    }
}
//6 
int calculatePerimeter(int length, int width) {
    return 2 * (length + width);
}
int calculateArea(int length, int width) {
    return length * width;
}
void drawRectangle(int length, int width) {
    for (int i = 0; i < length; ++i) {
        for (int j = 0; j < width; ++j) {
            cout << "* ";
        }
        cout << endl;
    }
}
//7
bool isPerfectNumber(int num) {
    int sum = 1;
    for (int i = 2; i * i <= num; ++i) {
        if (num % i == 0) {
            sum += i;
            if (i * i != num) {
                sum += num / i;
            }
        }
    }
    return (sum == num);
}
void printPerfectNumbers(int N) {
    cout << "Cac so hoan thien nho hon " << N << " la: ";
    for (int i = 2; i < N; ++i) {
        if (isPerfectNumber(i)) {
            cout << i << " ";
        }
    }
    cout << endl;
}
//8 
vector<int> countCurrency(int amount) {
    vector<int> currencyCounts(6, 0);
    int denominations[] = {50000, 20000, 10000, 5000, 2000, 1000};
    for (int i = 0; i < 6; ++i) {
        currencyCounts[i] = amount / denominations[i];
        amount = amount % denominations[i];
    }
    return currencyCounts;
}
void printAllCombinations(int amount) {
    cout << "Cac phuong an co the co: " << endl;
    vector<int> currencyCounts = countCurrency(amount);
    int denominations[] = {50000, 20000, 10000, 5000, 2000, 1000};
    for (int i = 0; i < 6; ++i) {
        if (currencyCounts[i] > 0) {
            cout << currencyCounts[i] << " to " << denominations[i] << " VND" << endl;
        }
    }
}
void findMinimumCombination(int amount) {
    cout << "Phuong an co so to it nhat: " << endl;
    vector<int> currencyCounts = countCurrency(amount);
    int denominations[] = {50000, 20000, 10000, 5000, 2000, 1000};
    for (int i = 0; i < 6; ++i) {
        if (currencyCounts[i] > 0) {
            cout << currencyCounts[i] << " to " << denominations[i] << " VND" << endl;
            break;
        }
    }
}
//9
void daochuoi(string& str) {
    int trai = 0;
    int phai = str.length() - 1;

    while (trai < phai) {
        swap(str[trai], str[phai]);
        trai++;
        phai--;
    }
}
int daokytu(int n) {
    string str = to_string(n); 
    daochuoi(str); 
    return stoi(str); 
}
//14
string ones[] = {"", "mot", "hai", "ba", "bon", "nam", "sau", "bay", "tam", "chin"};

void doc1kytu(int num) {
    if (num >= 1 && num <= 9) {
        cout << ones[num] << endl;
    } else {
        cout << "So khong hop le!" << endl;
    }
}
void doc3kytu(int num) {
    int digit1 = num / 100; 
    int digit2 = (num / 10) % 10; 
    int digit3 = num % 10;

    if (digit1 != 0) {
        cout << ones[digit1] << " tram ";
    }

    if (digit2 != 0) {
        if (digit2 == 1) {
            cout << "muoi ";
        } else {
            cout << ones[digit2] << " muoi ";
        }
    } else {
        if (digit1 != 0 && digit3 != 0) {
            cout << "linh ";
        }
    }

    if (digit3 != 0) {
        if (digit2 == 0 && digit1 != 0) {
            cout << ones[digit3];
        } else if (digit2 == 1 && digit3 == 5) {
            cout << "lam";
        } else {
            cout << ones[digit3];
        }
    }
    cout << endl;
}
void dockytu(int num) {
    if (num == 0) {
        cout << "khong" << endl;
    } else if (num >= 1 && num <= 999) {
        doc3kytu(num);
    } else if (num >= 1000 && num < 1000000) {
        int thousands = num / 1000; 
        int remainder = num % 1000; 
        doc3kytu(thousands);
        cout << "nghin ";
        if (remainder != 0) {
            doc3kytu(remainder);
        }
    } else {
        cout << "So khong hop le!" << endl;
    }
}
//15
bool moinam(int nam) {
    return nam % 2 == 0;
}
void sukiensport(int nam) {
    cout << "Cac giai the thao lon duoc to chuc trong nam " << nam << ": ";

    if (nam % 4 == 0) {
        cout << "Olympic, Euro ";
    }

    if (nam % 4 == 2) {
        cout << "World Cup ";
    }

    if (nam % 2 == 1) {
        cout << "SEA Games";
    }

    if (nam >= 1996 && moinam(nam)) {
        cout << ", Tiger Cup";
    }

    cout << endl;
}
//16 
bool namnhuan(int nam) {
    return (nam % 4 == 0 && nam % 100 != 0) || (nam % 400 == 0);

}
bool ngaythang(int ngay, int thang, int nam) {
    if (thang < 1 || thang > 12 || ngay < 1) {
        return false;
    }

    int ngaytrongthang;
    switch (thang) {
        case 2:
            ngaytrongthang = namnhuan(nam) ? 29 : 28;
            break;
        case 4:
        case 6:
        case 9:
        case 11:
            ngaytrongthang = 30;
            break;
        default:
            ngaytrongthang = 31;
    }

    return ngay <= ngaytrongthang;
}
void ngayhomsau(int& ngay, int& thang, int& nam) {
    int ngaytrongthang;
    switch (thang) {
        case 2:
            ngaytrongthang = namnhuan(nam) ? 29 : 28;
            break;
        case 4:
        case 6:
        case 9:
        case 11:
            ngaytrongthang = 30;
            break;
        default:
            ngaytrongthang = 31;
    }

    ngay++;
    if (ngay > ngaytrongthang) {
        ngay = 1;
        thang++;
        if (thang > 12) {
            thang = 1;
            nam++;
        }
    }
}
void ngayhomtruoc(int& ngay, int& thang, int& nam) {
    ngay--;
    if (ngay < 1) {
        thang--;
        if (thang < 1) {
            thang = 12;
            nam--;
        }

        int ngaytrongthang;
        switch (thang) {
            case 2:
                ngaytrongthang = namnhuan(nam)? 29 : 28;
                break;
            case 4:
                break;
            case 6:
                break;
            case 9:
                break;
            case 11:
                ngaytrongthang = 30;
                break;
            default:
                ngaytrongthang = 31;
        }

        ngay = ngaytrongthang;
    }
}

int main()
{
    cout<<" Bài tập lab 3 ? " ;
    int n;
    cin>>n;
    switch (n) {
        case 1 : {
            int num1, num2, num3;
            cout << "Nhap ba so nguyen: ";
            cin >> num1 >> num2 >> num3;
        
            int min1 = minNumber(num1, num2);
            int min2 = minNumber(min1, num3);
        
            cout << "So nho nhat trong 3 so la: " << min2 << endl;
        }
        break;
        case 2 : {
            int num1, num2;
            cout << "Nhap hai so nguyen duong: ";
            cin >> num1 >> num2;
        
            int uscln = gcd(num1, num2);
            int bscnn = lcm(num1, num2);
        
            cout << "Uoc so chung lon nhat cua " << num1 << " va " << num2 << " la: " << uscln << endl;
            cout << "Boi so chung nho nhat cua " << num1 << " va " << num2 << " la: " << bscnn << endl;

        }break;
        case 3 : {
             int n;
            cout << "Nhap mot so nguyen duong n: ";
            cin >> n;
        
            if (n <= 1) {
                cout << "Khong tinh duoc giai thua!" << endl;
            } else {
                int result = factorial(n);
                cout << n << "! = " << result << endl;
            }    
        }
        break;
        case 4 : {
            double X;
            int m;
            cout << "Nhap mot so X: ";
            cin >> X;
        
            cout << "Nhap mot so nguyen m: ";
            cin >> m;
        
            double result = power(X, m);
            cout << X << "^" << m << " = " << result << endl;
        }
        break;
        case 5 : {
            int n, k;
            cout << "Nhap hai so nguyen n va k (n >= k): ";
            cin >> n >> k;
        
            int coefficient = binomialCoefficient(n, k);
            cout << "C(" << n << ", " << k << ") = " << coefficient << endl;
        }
        break;
        case 6 : {
            int length, width;
            cout << "Nhap do dai va chieu rong cua hinh chu nhat: ";
            cin >> length >> width;
        
            int perimeter = calculatePerimeter(length, width);
            int area = calculateArea(length, width);
        
            cout << "Chu vi hinh chu nhat: " << perimeter << endl;
            cout << "Dien tich hinh chu nhat: " << area << endl;
        
            cout << "Ve hinh chu nhat:" << endl;
            drawRectangle(length, width);
        }
        break;
        case 7 : {
            int N;
            cout << "Nhap so N: ";
            cin >> N;
        
            printPerfectNumbers(N);
        }
        break;
        case 8 : {
            int amount;
            cout << "Nhap so tien can tinh (VND): ";
            cin >> amount;
        
            printAllCombinations(amount);
            findMinimumCombination(amount);
        }
        break;
        case 9 : {
            int n;
            cout << "Nhap mot so nguyen duong: ";
            cin >> n;
        
            int daoso = daokytu(n);
            cout << "So sau khi dao nguoc vi tri cac chu so: " << daoso << endl;
        }
        break;
        case 14 : {
            int num;
            cout << "Nhap mot so nguyen < 1.000.000 : ";
            cin >> num;
            cout << "Chuoi cua so " << num << ": ";
            dockytu(num);
        }
        break;
        case 15 : {
            int nam;
            cout << "Nhap nam duong lich (tu 1975 tro di): ";
            cin >> nam;
            if (nam < 1975) {
                cout << "Nam khong hop le!" << endl;
                return 1;
            }
            sukiensport(nam);
        }
        break;
        case 16 : {
            int ngay,thang , nam;
            cout << "Nhap ngay, thang, nam hien tai: ";
            cin >> ngay >> thang >> nam;
        
            if (!ngaythang(ngay,thang , nam)) {
                cout << "Ngay hoac thang khong hop le!" << endl;
                return 1;
            }
            int ngaysau = ngay, thangsau = thang, namsau = nam;
            ngayhomsau(ngaysau, thangsau, namsau);
        
            int ngaytruoc = ngay, thangtruoc = thang, namtruoc = nam;
            ngayhomtruoc(ngaytruoc, thangtruoc, namtruoc);
        
            cout << "Thang " << thang << " nam " << nam << " co " << (namnhuan(nam) ? 29 : 28) << " ngay." << endl;
            cout << "Ngay hom sau: " << ngaysau << "/" << thangsau << "/" << namsau << endl;
            cout << "Ngay hom truoc: " << ngaytruoc << "/" << thangtruoc << "/" << namtruoc << endl;
        }
    }
}
